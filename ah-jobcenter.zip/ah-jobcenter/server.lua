local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP", "ah-jobcenter")

RegisterServerEvent("jobcenter:addgroup")
AddEventHandler("jobcenter:addgroup", function(group)
    local user_id = vRP.getUserId({source})
    vRP.addUserGroup({user_id,group})
    TriggerClientEvent('mythic_notify:client:SendAlert', source, { type = 'error', text = Config.Job.jobselected .. " " .. group})
end)