local delay = 300

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(delay)
        for _,v in pairs(Config.Jobcenter) do
            while GetDistanceBetweenCoords(GetEntityCoords(PlayerPedId()), v.x,v.y,v.z, true) <= 1 do
                delay = 1
                Citizen.Wait(delay)
                    DrawText3Ds(v.x,v.y,v.z+0.2,"~b~[E]~w~ Jobcenter")
                    if IsControlJustReleased(1, 38) then
                    TriggerEvent('open:jobcenter')
                    end
            delay = 300
            end
        end
    end
end)

RegisterNetEvent("open:jobcenter")
AddEventHandler("open:jobcenter", function()
    SetNuiFocus(true, true)
    SendNUIMessage({
        type = "home",
        status = true,
    })
end)

RegisterNetEvent("jobcenter:jobs")
AddEventHandler("jobcenter:jobs", function()
    SetNuiFocus(true, true)
    SendNUIMessage({
        type = "jobs",
        status = true,
    })
end)

RegisterNUICallback("Luk", function (data)
    SetNuiFocus(false, false)
end)

RegisterNUICallback("jobs", function (data)
    TriggerEvent("jobcenter:jobs")
end)

RegisterNUICallback("skraldemand", function(data)
    if data.group ~= nil then
      TriggerServerEvent("jobcenter:addgroup", data.group)
    end
end)

RegisterNUICallback("taxa", function(data)
    if data.group ~= nil then
      TriggerServerEvent("jobcenter:addgroup", data.group)
    end
end)

RegisterNUICallback("lastbil", function(data)
    if data.group ~= nil then
      TriggerServerEvent("jobcenter:addgroup", data.group)
    end
end)

RegisterNUICallback("miner", function(data)
    if data.group ~= nil then
      TriggerServerEvent("jobcenter:addgroup", data.group)
    end
end)

RegisterNUICallback("haendvaerker", function(data)
    if data.group ~= nil then
      TriggerServerEvent("jobcenter:addgroup", data.group)
    end
end)

RegisterNUICallback("postbud", function(data)
    if data.group ~= nil then
      TriggerServerEvent("jobcenter:addgroup", data.group)
    end
end)

-- 3D TEXT --
function DrawText3Ds(x,y,z, text)
    local onScreen,_x,_y=World3dToScreen2d(x,y,z)
    local px,py,pz=table.unpack(GetGameplayCamCoords())
    SetTextScale(0.38, 0.38)
    SetTextFont(6)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextOutline()
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x,_y)
end
