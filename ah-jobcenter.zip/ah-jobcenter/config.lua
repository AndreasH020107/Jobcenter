Config = {}

Config.Jobcenter = {
    {x=-268.70877075195,y=-956.54730224609,z=31.223125457764} -- -268.70877075195,-956.54730224609,31.223125457764
}

Config.Job = {
    jobselected = "Tilykke med dit nye job! - Du har valgte:"
}