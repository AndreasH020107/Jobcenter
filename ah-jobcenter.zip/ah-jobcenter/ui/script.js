window.addEventListener('message', function(event) {
    var item = event.data;

    if (item.status == true) {
        $("#jobs").hide();
        $("#home").show();
        $("container").show();
	}
    if(item.type == 'jobs') {
        $("#home").hide();
        $("#jobs").show();
    }
	else if (item.status == false){
    $("container").fadeOut();
	}
});

document.onkeyup = function (data) {
    if (data.which == 27) {
        $("container").fadeOut();
        $.post("http://ah-jobcenter/Luk");
    }
};

function jobs() {
    $.post("http://ah-jobcenter/jobs");
}

function hjembtn() {
    $("#home").show();
    $("#jobs").hide();
}

$(".selectJob").click(function () {
    let jobID = $(this).data("jobID");
    if(!configs.jobs[jobID].whitelisted) {
      let group = configs.jobs[jobID].group;
      $.post('http://ah-jobcenter/selectJob', JSON.stringify({
        group: group
      }));
    }
});

function skraldemand() {
	$.post("http://ah-jobcenter/skraldemand", JSON.stringify({
        group: "Skraldemand"
    }));
}

function taxa() {
	$.post("http://ah-jobcenter/taxa", JSON.stringify({
        group: "Taxi"
    }));
}

function lastbil() {
	$.post("http://ah-jobcenter/lastbil", JSON.stringify({
        group: "Lastbilchauffør"
    }));
}

function miner() {
	$.post("http://ah-jobcenter/miner", JSON.stringify({
        group: "Miner"
    }));;
}

function haendvaerker() {
	$.post("http://ah-jobcenter/haendvaerker", JSON.stringify({
        group: "handvarker"
    }));
}

function postbud() {
	$.post("http://ah-jobcenter/postbud", JSON.stringify({
        group: "Postbud"
    }));
}